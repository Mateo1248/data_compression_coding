package lista1;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;

public class Main
{
    public static void main(String[] args)
    {
        File file = new File("C:\\Users\\Dawid\\IdeaProjects\\KKD\\testy\\ptad.txt");
        readContentIntoByteArray(file);
    }

    private static void readContentIntoByteArray(File file)
    {
        FileInputStream fileInputStream;
        byte[] byteArray = new byte[(int) file.length()];

        try
        {
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(byteArray);
            fileInputStream.close();

            System.out.println("Entropia           = "+ entropy(byteArray));
            System.out.println("Entropia warunkowa = "+ condEntropy(byteArray));
            System.out.println("Różnica            = "+ (entropy(byteArray)-condEntropy(byteArray)));
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private static double entropy(byte[] byteArray){

        ArrayList<Symbol> symbols = new ArrayList<>();
        for (byte b : byteArray) {
            symbols.add(new Symbol(b, 1));

            for (int i = 0; i < symbols.size() - 1; i++) {
                if (symbols.get(i).getName() == b) {
                    symbols.get(i).setCount(symbols.get(i).getCount() + 1);
                    symbols.remove(symbols.size() - 1);

                }
            }
        }

        double H = 0.0;
        for (Symbol s: symbols) {
            H -= s.getCount()/byteArray.length * Math.log(s.getCount()/byteArray.length) / Math.log(2);
        }
        return H;
    }

    private static double condEntropy(byte[] byteArray){

        ArrayList<Symbol> symbols = new ArrayList<>();
        boolean temp=false;

        for (int x = 0; x<byteArray.length; ++x){
            symbols.add(new Symbol(byteArray[x], 1));

            if(x==0){
                Symbol s = new Symbol((byte) 0, 1);
                symbols.get(0).addToPrevElements(s);
            }else{
                Symbol s = new Symbol(byteArray[x-1], 1);
                for (int i = 0; i < symbols.size() - 1; i++) {
                    if (symbols.get(i).getName() == byteArray[x]) {
                        symbols.get(i).setCount(symbols.get(i).getCount() + 1);
                        symbols.get(i).addToPrevElements(s);
                        temp = true;
                        symbols.remove(symbols.size() - 1);
                    }
                }

                if(!temp){
                    symbols.get(symbols.size()-1).addToPrevElements(s);
                }
                temp=false;
            }
        }

        double H = 0.0;

        for (Symbol s: symbols) {
            for(Symbol prev: s.getPrevElements()){
                H -= prev.getCount()/byteArray.length * (Math.log(prev.getCount()) / Math.log(2) - Math.log(s.getCount())/Math.log(2));
            }
        }
        return H;
    }
}

