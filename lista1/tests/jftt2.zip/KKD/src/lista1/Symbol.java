package lista1;

import java.util.ArrayList;

public class Symbol {
    private byte name;
    private double count;
    private ArrayList<Symbol> prevElements;

    public Symbol(byte name, double count){
        this.name = name;
        this.count= count;
        this.prevElements = new ArrayList<>();
    }

    public void setCount(double count){
        this.count=count;
    }
    public double getCount(){
        return count;
    }

    public byte getName(){
        return name;
    }

    public ArrayList<Symbol> getPrevElements(){
        return prevElements;
    }

    public void addToPrevElements(Symbol s){
        this.prevElements.add(s);
        for (int i = 0; i < this.prevElements.size() - 1; i++) {
            if (this.prevElements.get(i).getName() == s.getName()) {
                this.prevElements.get(i).setCount(this.prevElements.get(i).getCount() + 1);
                this.prevElements.remove(this.prevElements.size() - 1);
            }
        }
    }
}
